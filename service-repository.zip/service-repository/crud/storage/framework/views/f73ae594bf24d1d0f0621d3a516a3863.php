<h2>edit data</h2>
<form action="/siswa/edit<?php echo e($result [0]['id']); ?>"  method="POST">
    <?php echo csrf_field(); ?>
    <div>
        <label for="nama" class="form-label">Nama</label>
        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($result [0]['nama']); ?>">
    </div>
    <br>
    <div class>
        <label for="jurusan" class="form-label">Jurusan</label>
        <input type="text" class="form-control" id="jurusan" name="jurusan" value="<?php echo e($result [0]['jurusan']); ?>">
    </div>
    <br>
    <input type="submit" />
</form><?php /**PATH C:\srp_crud\crud\resources\views/update.blade.php ENDPATH**/ ?>