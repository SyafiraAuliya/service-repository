
<?php $__env->startSection('content'); ?>
    <h2>data siswa</h2>

    <table border="1">
        <thead>
            <tr>
                <th scope="col">Nama</th>
                <th scope="col">Jurusan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data->nama); ?></td>
                    <td><?php echo e($data->jurusan); ?></td>
                    <td>
                        <a href="/siswa/update<?php echo e($data['id']); ?>">edit</a>
                        <a href="/siswa/delete<?php echo e($data['id']); ?>">hapus</a>
                    </td>
                </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php /**PATH C:\srp_crud\crud\resources\views/table.blade.php ENDPATH**/ ?>