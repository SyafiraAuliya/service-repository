<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       
        <title>CRUD | tambah</title>
    </head>
    <body class="antialiased">
    <div class="container mt-4">
        
        <?php $__env->startSection('content'); ?>
            <h2>data siswa</h2>
        
            <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-primary">tambah data</a>
            <table class="table mt-4">
                <thead>
                    <tr>
                        <th scope="col">Nama</th>
                        <th scope="col">Jurusan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($data->nama); ?></td>
                            <td><?php echo e($data->kelas); ?></td>
                            <td>
                                <a href="<?php echo e(route('siswa.edit', $data->id)); ?>" class="btn btn-sm">edit</a>
                                <form action="<?php echo e(route('siswa.destroy', $data->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php $__env->stopSection(); ?>
    </div>
    </body>
</html>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\srp_crud\crud\resources\views/welcome.blade.php ENDPATH**/ ?>